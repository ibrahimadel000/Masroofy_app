import 'package:flutter_test/flutter_test.dart';
import 'package:mizaan/core/constants/app_constants.dart';
import 'package:mizaan/core/constants/sms_senders.dart';
import 'package:mizaan/core/utils/smart_sms_parser.dart';
import 'package:mizaan/data/models/transaction_model.dart';
import 'package:mizaan/data/repositories/transaction_repository.dart';

void main() {
  group('Real Yemeni Wallets SMS Parsing Tests (Step 6 Verification)', () {
    final testDate = DateTime(2026, 9, 6, 22, 10);

    test('Kuraimi Bank real SMS 1 — Salary/Deposit (Income 50,000.00)', () {
      const sender = 'KuraimiMB';
      const body = 'أودع/عادل عبدالواحد لحسابك50,000.00\n51,245.30YERرصيدك';

      final parsed = SmsSenderRegistry.parseMessage(
        sender: sender,
        body: body,
        date: testDate,
      );

      expect(parsed, isNotNull);
      expect(parsed!.walletType, 'kuraimi');
      expect(parsed.type, 'income');
      expect(parsed.amount, 50000.0);
      expect(parsed.balance, 51245.30);
      expect(parsed.category, 'تحويل');
    });

    test('Kuraimi Bank real SMS 2 — Bill payment (Expense 400.00)', () {
      const sender = 'KuraimiMB';
      const body = 'تم سداد 400.00 جوال 772004664\nYER 2,545.30 رصيدك';

      final parsed = SmsSenderRegistry.parseMessage(
        sender: sender,
        body: body,
        date: testDate,
      );

      expect(parsed, isNotNull);
      expect(parsed!.walletType, 'kuraimi');
      expect(parsed.type, 'expense');
      expect(parsed.amount, 400.0);
      expect(parsed.balance, 2545.30);
      expect(parsed.category, 'فواتير');
    });

    test('Kuraimi Bank real SMS 3 — Transfer out (Expense 1,100.00)', () {
      const sender = 'KuraimiIMB';
      const body = 'تم تحويل1,100.00لحساب خليل الرحمن\nرصيدك1,445.30YER';

      final parsed = SmsSenderRegistry.parseMessage(
        sender: sender,
        body: body,
        date: testDate,
      );

      expect(parsed, isNotNull);
      expect(parsed!.walletType, 'kuraimi');
      expect(parsed.type, 'expense');
      expect(parsed.amount, 1100.0);
      expect(parsed.balance, 1445.30);
      expect(parsed.category, 'تحويل');
    });

    test('Kuraimi Bank real SMS 4 — Merchant Purchase (Expense 100.00)', () {
      const sender = 'KuraimiIMB';
      const body = 'تم خصم مبلغ YER 100.00 مقابل مشترياتك من 1588993\nالمرجع: 54177667';

      final parsed = SmsSenderRegistry.parseMessage(
        sender: sender,
        body: body,
        date: testDate,
      );

      expect(parsed, isNotNull);
      expect(parsed!.walletType, 'kuraimi');
      expect(parsed.type, 'expense');
      expect(parsed.amount, 100.0);
      expect(parsed.balance, isNull);
      expect(parsed.category, 'بقالة');
    });

    test('Kuraimi Bank real SMS 5 — Multiline Deposit with مبلغ (Income 100.0)', () {
      const sender = 'KuraimiIMB';
      const body = 'أودع/ابراهيم عادل عبدالواحد الشرجبي\nلحسابك مبلغ 100 رصيدك YER 4045.3';

      final parsed = SmsSenderRegistry.parseMessage(
        sender: sender,
        body: body,
        date: testDate,
      );

      expect(parsed, isNotNull);
      expect(parsed!.walletType, 'kuraimi');
      expect(parsed.type, 'income');
      expect(parsed.amount, 100.0);
      expect(parsed.balance, 4045.3);
      expect(parsed.isBalanceOnly, isFalse);
      expect(parsed.category, 'تحويل');
    });

    test('Kuraimi Bank real SMS 5b (User Case) — Deposit 500 with Balance 4045.3', () {
      const sender = 'Kuraimi';
      const body = 'أودع/ابراهيم عادل عبدالواحد الشرجبي\nلحسابك مبلغ 500 رصيدك YER 4045.3';

      final parsed = SmsSenderRegistry.parseMessage(
        sender: sender,
        body: body,
        date: testDate,
      );

      expect(parsed, isNotNull);
      expect(parsed!.walletType, 'kuraimi');
      expect(parsed.type, 'income');
      expect(parsed.amount, 500.0); // Specifically verify amount is 500, NOT 4045!
      expect(parsed.balance, 4045.3);
      expect(parsed.isBalanceOnly, isFalse);
      expect(parsed.category, 'تحويل');
    });

    test('Kuraimi Bank Pure Balance Inquiry — Reconcile without fake income', () {
      const sender = 'Kuraimi';
      const body = 'رصيد حسابك في بنك الكريمي هو 3000 YER';

      final parsed = SmsSenderRegistry.parseMessage(
        sender: sender,
        body: body,
        date: testDate,
      );

      expect(parsed, isNotNull);
      expect(parsed!.walletType, 'kuraimi');
      expect(parsed.type, 'adjustment');
      expect(parsed.amount, 0.0);
      expect(parsed.balance, 3000.0);
      expect(parsed.isBalanceOnly, isTrue);
    });

    test('Kuraimi Bank real SMS 6 — Mobile Bill payment (Expense 200.00)', () {
      const sender = 'KuraimiIMB';
      const body = 'تم سداد 200.00 جوال 772004664 رصيدك YER 51,045.30';

      final parsed = SmsSenderRegistry.parseMessage(
        sender: sender,
        body: body,
        date: testDate,
      );

      expect(parsed, isNotNull);
      expect(parsed!.walletType, 'kuraimi');
      expect(parsed.type, 'expense');
      expect(parsed.amount, 200.0);
      expect(parsed.balance, 51045.30);
      expect(parsed.category, 'فواتير');
    });

    test('Jaib Wallet real SMS 1 — Transfer In (Income 500)', () {
      const sender = 'Jaib';
      const body = 'اضيف 500ر.ي تحويل مشترك\nرص:5680ر.ي من سام النزيلي-781563420';

      final parsed = SmsSenderRegistry.parseMessage(
        sender: sender,
        body: body,
        date: testDate,
      );

      expect(parsed, isNotNull);
      expect(parsed!.walletType, 'jeeb');
      expect(parsed.type, 'income');
      expect(parsed.amount, 500.0);
      expect(parsed.balance, 5680.0);
      expect(parsed.category, 'تحويل');
    });

    test('Jaib Wallet real SMS 2 — Mobile bill deduction (Expense 250)', () {
      const sender = 'Jaib';
      const body = 'خصم 250ر.ي رص:4330ر.ي للرقم 772004664 سداد يمن موبايل';

      final parsed = SmsSenderRegistry.parseMessage(
        sender: sender,
        body: body,
        date: testDate,
      );

      expect(parsed, isNotNull);
      expect(parsed!.walletType, 'jeeb');
      expect(parsed.type, 'expense');
      expect(parsed.amount, 250.0);
      expect(parsed.balance, 4330.0);
      expect(parsed.category, 'فواتير');
    });

    test('Jaib Wallet real SMS 3 — Small deduction (Expense 100)', () {
      const sender = 'Jaib';
      const body = 'خصم 100ر.ي رص:4230ر.ي للرقم 772004664 سداد يمن موبايل';

      final parsed = SmsSenderRegistry.parseMessage(
        sender: sender,
        body: body,
        date: testDate,
      );

      expect(parsed, isNotNull);
      expect(parsed!.walletType, 'jeeb');
      expect(parsed.type, 'expense');
      expect(parsed.amount, 100.0);
      expect(parsed.balance, 4230.0);
      expect(parsed.category, 'فواتير');
    });

    test('Deduplication fingerprint hash generates consistent key despite timestamp drift on same day', () {
      const sender = 'Jaib';
      const body = 'خصم 100ر.ي رص:4230ر.ي للرقم 772004664 سداد يمن موبايل';
      final key1 = SmsSenderRegistry.generateSmsKey(sender, testDate, body);
      final key2 = SmsSenderRegistry.generateSmsKey(sender, testDate, body);
      // Even if live listener got DateTime.now() 1 minute later than carrier SMS timestamp:
      final key3 = SmsSenderRegistry.generateSmsKey(sender, testDate.add(const Duration(minutes: 1)), body);
      // Different day produces different key:
      final key4 = SmsSenderRegistry.generateSmsKey(sender, testDate.add(const Duration(days: 1)), body);

      expect(key1, key2);
      expect(key1, key3); // Prevents timestamp drift duplication!
      expect(key1, isNot(key4));
    });

    test('User Real Case 1: Kuraimi Transfer 4100 with Suffix Balance 945.30YERرصيدك', () {
      const sender = 'Kuraimi';
      const body = 'تم تحويل4,100.00لحساب خليل الرحمن\n945.30YERرصيدك';

      final parsed = SmsSenderRegistry.parseMessage(
        sender: sender,
        body: body,
        date: testDate,
      );

      expect(parsed, isNotNull);
      expect(parsed!.walletType, 'kuraimi');
      expect(parsed.type, 'expense');
      expect(parsed.amount, 4100.0);
      expect(parsed.balance, 945.30);
      expect(parsed.category, 'تحويل');
    });

    test('User Real Case 2: Kuraimi Deposit 1000 with Suffix Balance 5,045.30YERرصيدك', () {
      const sender = 'Kuraimi';
      const body = 'أودع/عادل عبدالواحد لحسابك1,000.00\n5,045.30YERرصيدك';

      final parsed = SmsSenderRegistry.parseMessage(
        sender: sender,
        body: body,
        date: testDate,
      );

      expect(parsed, isNotNull);
      expect(parsed!.walletType, 'kuraimi');
      expect(parsed.type, 'income');
      expect(parsed.amount, 1000.0);
      expect(parsed.balance, 5045.30);
      expect(parsed.category, 'تحويل');
    });

    test('User Real Case 3: Kuraimi Purchase with Reference Number extraction', () {
      const sender = 'Kuraimi';
      const body = 'تم خصم مبلغ YER 100.00 مقابل مشترياتك من 1588993\nالمرجع: 54477347';

      final parsed = SmsSenderRegistry.parseMessage(
        sender: sender,
        body: body,
        date: testDate,
      );

      expect(parsed, isNotNull);
      expect(parsed!.walletType, 'kuraimi');
      expect(parsed.type, 'expense');
      expect(parsed.amount, 100.0);
      expect(parsed.referenceNumber, '54477347');
      expect(parsed.category, 'بقالة');

      // Verify reference number based key is 100% stable regardless of date
      final keyA = SmsSenderRegistry.generateSmsKey(sender, testDate, body);
      final keyB = SmsSenderRegistry.generateSmsKey(sender, testDate.add(const Duration(days: 30)), body);
      expect(keyA, keyB);
    });

    test('Unregistered/Personal SMS is skipped completely', () {
      const sender = '777123456';
      const body = 'السلام عليكم، كيف حالك أخي؟';

      final parsed = SmsSenderRegistry.parseMessage(
        sender: sender,
        body: body,
        date: testDate,
      );

      expect(parsed, isNull);
    });

    test('SMS Arrival timestamp preservation and formatting in Arabic', () {
      final arrivalTime = DateTime(2026, 9, 15, 20, 45); // 08:45 PM
      const sender = 'KuraimiMB';
      const body = 'أودع/عادل عبدالواحد لحسابك50,000.00\n51,245.30YERرصيدك';

      final parsed = SmsSenderRegistry.parseMessage(
        sender: sender,
        body: body,
        date: arrivalTime,
      );

      expect(parsed, isNotNull);
      expect(parsed!.date, arrivalTime);
      expect(parsed.date.hour, 20);
      expect(parsed.date.minute, 45);

      final formattedTime = AppConstants.formatTime(arrivalTime);
      expect(formattedTime.contains('08:45') || formattedTime.contains('8:45') || formattedTime.contains('٢٠:٤٥') || formattedTime.contains('٠٨:٤٥'), isTrue);

      final formattedDateTime = AppConstants.formatDateTime(arrivalTime);
      expect(formattedDateTime.contains('2026') || formattedDateTime.contains('٢٠٢٦'), isTrue);
    });

    test('formatTime morning AM formatting', () {
      final morningTime = DateTime(2026, 9, 15, 9, 15); // 09:15 AM
      final formattedTime = AppConstants.formatTime(morningTime);
      expect(formattedTime.contains('09:15') || formattedTime.contains('9:15') || formattedTime.contains('٠٩:١٥'), isTrue);
    });

    test('Jaib Wallet Pure Balance Inquiry — Reconcile without fake income', () {
      const sender = 'Jaib';
      const body = 'رصيدك: 5680 YER';

      final parsed = SmsSenderRegistry.parseMessage(
        sender: sender,
        body: body,
        date: testDate,
      );

      expect(parsed, isNotNull);
      expect(parsed!.walletType, 'jeeb');
      expect(parsed.type, 'adjustment');
      expect(parsed.amount, 0.0);
      expect(parsed.balance, 5680.0);
      expect(parsed.isBalanceOnly, isTrue);
    });

    test('Kash Wallet Deposit with Balance Disambiguation', () {
      const sender = 'Kash';
      const body = 'إيداع 1000 رصيدك YER 4000';

      final parsed = SmsSenderRegistry.parseMessage(
        sender: sender,
        body: body,
        date: testDate,
      );

      expect(parsed, isNotNull);
      expect(parsed!.walletType, 'kash');
      expect(parsed.type, 'income');
      expect(parsed.amount, 1000.0);
      expect(parsed.balance, 4000.0);
      expect(parsed.isBalanceOnly, isFalse);
    });

    test('Jawali Wallet Deduction with Balance Disambiguation', () {
      const sender = 'Jawali';
      const body = 'خصم 300 رصيدك: 2700';

      final parsed = SmsSenderRegistry.parseMessage(
        sender: sender,
        body: body,
        date: testDate,
      );

      expect(parsed, isNotNull);
      expect(parsed!.walletType, 'jawali');
      expect(parsed.type, 'expense');
      expect(parsed.amount, 300.0);
      expect(parsed.balance, 2700.0);
      expect(parsed.isBalanceOnly, isFalse);
    });

    test('Deduplication: TransactionRepository.deduplicateList collapses duplicate SMS transactions across varying timestamps', () {
      final tx1 = TransactionModel(
        id: 'uuid_1',
        walletId: 'kuraimi_1',
        type: 'expense',
        amount: 4100.0,
        category: 'تحويل',
        note: 'تم تحويل4,100.00لحساب خليل الرحمن\n945.30YERرصيدك',
        rawSmsBody: 'تم تحويل4,100.00لحساب خليل الرحمن\n945.30YERرصيدك',
        date: DateTime(2026, 9, 17, 1, 21),
        source: 'sms',
        createdAt: DateTime(2026, 9, 17, 1, 21),
      );

      final tx2 = TransactionModel(
        id: 'uuid_2',
        walletId: 'kuraimi_1',
        type: 'expense',
        amount: 4100.0,
        category: 'تحويل',
        note: 'تم تحويل4,100.00لحساب خليل الرحمن\n945.30YERرصيدك',
        rawSmsBody: 'تم تحويل4,100.00لحساب خليل الرحمن\n945.30YERرصيدك',
        date: DateTime(2026, 9, 17, 8, 45), // 7 hours later
        source: 'sms',
        createdAt: DateTime(2026, 9, 17, 8, 45),
      );

      final result = TransactionRepository.deduplicateList([tx1, tx2]);
      expect(result.length, 1);
      expect(result.first.id, 'uuid_1');
    });

    test('Deduplication: normalizeBodyForComparison matches despite whitespace or Arabic digits variations', () {
      final norm1 = TransactionRepository.normalizeBodyForComparison('تم تحويل4,100.00لحساب خليل الرحمن\n945.30YERرصيدك');
      final norm2 = TransactionRepository.normalizeBodyForComparison('تم تحويل 4,100.00 لحساب خليل الرحمن \r\n 945.30 YER رصيدك');
      expect(norm1, norm2);
    });

    test('Deduplication: Two separate purchases of the same amount on the same day are NOT dropped', () {
      final purchase1 = TransactionModel(
        id: 'tx_buy_1',
        walletId: 'kuraimi_1',
        type: 'expense',
        amount: 500.0,
        category: 'بقالة',
        note: 'تم سداد مشترياتك عبر حاسب 500 YER المرجع: 101',
        rawSmsBody: 'تم سداد مشترياتك عبر حاسب 500 YER المرجع: 101',
        date: DateTime(2026, 9, 17, 10, 0),
        source: 'sms',
        createdAt: DateTime(2026, 9, 17, 10, 0),
      );

      final purchase2 = TransactionModel(
        id: 'tx_buy_2',
        walletId: 'kuraimi_1',
        type: 'expense',
        amount: 500.0,
        category: 'بقالة',
        note: 'تم سداد مشترياتك عبر حاسب 500 YER المرجع: 102',
        rawSmsBody: 'تم سداد مشترياتك عبر حاسب 500 YER المرجع: 102',
        date: DateTime(2026, 9, 17, 14, 30), // Same day, different purchase!
        source: 'sms',
        createdAt: DateTime(2026, 9, 17, 14, 30),
      );

      final result = TransactionRepository.deduplicateList([purchase1, purchase2]);
      expect(result.length, 2, reason: 'Both legitimate purchases of 500 YER must be kept');
    });

    test('Kuraimi Haseb purchase SMS parsing (Expense 500.0 YER with Reference)', () {
      const sender = 'Haseb';
      const body = 'تم سداد مشترياتك عبر خدمة حاسب بمبلغ 500 YER لدى سوبرماركت الهدى المرجع: 556677';

      final parsed = SmsSenderRegistry.parseMessage(
        sender: sender,
        body: body,
        date: testDate,
      );

      expect(parsed, isNotNull);
      expect(parsed!.walletType, 'kuraimi');
      expect(parsed.type, 'expense');
      expect(parsed.amount, 500.0);
      expect(parsed.referenceNumber, '556677');
      expect(parsed.category, 'بقالة');
    });

    test('Kuraimi POS purchase SMS parsing (Expense 350.00 YER with Balance)', () {
      const sender = 'KuraimiMB';
      const body = 'تمت عملية شراء عبر نقاط البيع بمبلغ 350.00 YER رصيدك 4,200.00 YER المرجع: 998877';

      final parsed = SmsSenderRegistry.parseMessage(
        sender: sender,
        body: body,
        date: testDate,
      );

      expect(parsed, isNotNull);
      expect(parsed!.walletType, 'kuraimi');
      expect(parsed.type, 'expense');
      expect(parsed.amount, 350.0);
      expect(parsed.balance, 4200.0);
      expect(parsed.referenceNumber, '998877');
      expect(parsed.category, 'بقالة');
    });

    test('Kuraimi Arabic sender "الكريمي" purchase SMS parsing', () {
      const sender = 'الكريمي';
      const body = 'تم شراء بمبلغ 1200 ر.ي من محطة السلام رصيدك 18000 ر.ي رقم العملية: 443322';

      final parsed = SmsSenderRegistry.parseMessage(
        sender: sender,
        body: body,
        date: testDate,
      );

      expect(parsed, isNotNull);
      expect(parsed!.walletType, 'kuraimi');
      expect(parsed.type, 'expense');
      expect(parsed.amount, 1200.0);
      expect(parsed.balance, 18000.0);
      expect(parsed.referenceNumber, '443322');
    });

    test('OneCash wallet purchase and transfer parsing', () {
      const sender = 'OneCash';
      const body = 'تمت عملية شراء بمبلغ 1,500 ريال لدى متجر النور رصيدك الحالي 25,000 ريال مرجع: 778899';

      final parsed = SmsSenderRegistry.parseMessage(
        sender: sender,
        body: body,
        date: testDate,
      );

      expect(parsed, isNotNull);
      expect(parsed!.walletType, 'onecash');
      expect(parsed.type, 'expense');
      expect(parsed.amount, 1500.0);
      expect(parsed.balance, 25000.0);
      expect(parsed.referenceNumber, '778899');
    });

    test('Al-Amqi wallet SMS parsing', () {
      const sender = 'AlAmqi';
      const body = 'تم تحويل مبلغ 8000 ريال الى حساب سالم رصيدك 42000 ريال رقم الاشعار 12345';

      final parsed = SmsSenderRegistry.parseMessage(
        sender: sender,
        body: body,
        date: testDate,
      );

      expect(parsed, isNotNull);
      expect(parsed!.walletType, 'alamqi');
      expect(parsed.type, 'expense');
      expect(parsed.amount, 8000.0);
      expect(parsed.balance, 42000.0);
      expect(parsed.referenceNumber, '12345');
    });

    test('Floosak wallet SMS parsing', () {
      const sender = 'Floosak';
      const body = 'تم استلام حوالة بمبلغ 10000 ريال من احمد رصيدك المتاح 35000 ريال رقم العملية: 98765';

      final parsed = SmsSenderRegistry.parseMessage(
        sender: sender,
        body: body,
        date: testDate,
      );

      expect(parsed, isNotNull);
      expect(parsed!.walletType, 'floosak');
      expect(parsed.type, 'income');
      expect(parsed.amount, 10000.0);
      expect(parsed.balance, 35000.0);
      expect(parsed.referenceNumber, '98765');
    });

    test('Kuraimi deposit variant with "في حسابك" (Income 25,000)', () {
      const sender = 'KuraimiMB';
      const body = 'أودع فلان في حسابك مبلغ 25,000 ر.ي رصيدك 75,000 ر.ي';

      final parsed = SmsSenderRegistry.parseMessage(
        sender: sender,
        body: body,
        date: testDate,
      );

      expect(parsed, isNotNull);
      expect(parsed!.walletType, 'kuraimi');
      expect(parsed.type, 'income');
      expect(parsed.amount, 25000.0);
      expect(parsed.balance, 75000.0);
    });

    test('Kuraimi deposit with phone number and account number does NOT confuse amount (Income 30,000)', () {
      const sender = 'Kuraimi';
      const body = 'أودع/علي 771234567 لحسابك 12345678 بمبلغ 30,000 ريال رصيدك 80,000 ريال';

      final parsed = SmsSenderRegistry.parseMessage(
        sender: sender,
        body: body,
        date: testDate,
      );

      expect(parsed, isNotNull);
      expect(parsed!.walletType, 'kuraimi');
      expect(parsed.type, 'income');
      expect(parsed.amount, 30000.0);
      expect(parsed.balance, 80000.0);
    });

    test('Kuraimi inward transfer "تم تحويل ... لحسابك" is recorded as Income (Income 15,000)', () {
      const sender = 'KuraimiMB';
      const body = 'تم تحويل مبلغ 15000 ريال لحسابك من فؤاد رصيدك 65000 ريال';

      final parsed = SmsSenderRegistry.parseMessage(
        sender: sender,
        body: body,
        date: testDate,
      );

      expect(parsed, isNotNull);
      expect(parsed!.walletType, 'kuraimi');
      expect(parsed.type, 'income');
      expect(parsed.amount, 15000.0);
      expect(parsed.balance, 65000.0);
    });

    test('Kuraimi cash deposit "تم إيداع نقدي" (Income 40,000)', () {
      const sender = 'Kuraimi';
      const body = 'تم إيداع نقدي بمبلغ 40000 ر.ي في حسابك رصيدك 90000 ر.ي';

      final parsed = SmsSenderRegistry.parseMessage(
        sender: sender,
        body: body,
        date: testDate,
      );

      expect(parsed, isNotNull);
      expect(parsed!.walletType, 'kuraimi');
      expect(parsed.type, 'income');
      expect(parsed.amount, 40000.0);
      expect(parsed.balance, 90000.0);
    });

    test('Kuraimi account feed with haa "تغذيه" (Income 20,000)', () {
      const sender = 'KuraimiMB';
      const body = 'تغذيه حسابك بمبلغ 20000 ريال رصيدك 50000 ريال';

      final parsed = SmsSenderRegistry.parseMessage(
        sender: sender,
        body: body,
        date: testDate,
      );

      expect(parsed, isNotNull);
      expect(parsed!.walletType, 'kuraimi');
      expect(parsed.type, 'income');
      expect(parsed.amount, 20000.0);
      expect(parsed.balance, 50000.0);
    });

    test('Jaib wallet deposit with haa "تمت اضافه" (Income 5,000)', () {
      const sender = 'Jaib';
      const body = 'تمت اضافه 5000 ر.ي الى محفظتك جيب رصيدك 15000 ر.ي';

      final parsed = SmsSenderRegistry.parseMessage(
        sender: sender,
        body: body,
        date: testDate,
      );

      expect(parsed, isNotNull);
      expect(parsed!.walletType, 'jeeb');
      expect(parsed.type, 'income');
      expect(parsed.amount, 5000.0);
      expect(parsed.balance, 15000.0);
    });

    test('Jaib inward transfer "تم تحويل ... إلى محفظتك" is Income (Income 8,000)', () {
      const sender = 'Jaib';
      const body = 'تم تحويل 8000 ر.ي إلى محفظتك جيب من 777123456 رص: 23000ر.ي';

      final parsed = SmsSenderRegistry.parseMessage(
        sender: sender,
        body: body,
        date: testDate,
      );

      expect(parsed, isNotNull);
      expect(parsed!.walletType, 'jeeb');
      expect(parsed.type, 'income');
      expect(parsed.amount, 8000.0);
      expect(parsed.balance, 23000.0);
    });

    test('PYes (بايس) deposit SMS parsed as pyes wallet (Income 12,000)', () {
      const sender = 'PYes';
      const body = 'تم استلام حوالة بمبلغ 12000 ريال رصيدك 35000 مرجع 112233';

      final parsed = SmsSenderRegistry.parseMessage(
        sender: sender,
        body: body,
        date: testDate,
      );

      expect(parsed, isNotNull);
      expect(parsed!.walletType, 'pyes');
      expect(parsed.type, 'income');
      expect(parsed.amount, 12000.0);
      expect(parsed.balance, 35000.0);
      expect(parsed.referenceNumber, '112233');
    });

    test('Busairi (البصيري) deposit SMS parsed as busairi wallet (Income 50,000)', () {
      const sender = 'Busairi';
      const body = 'تم قيد مبلغ 50000 ريال لحسابكم طرفنا رقم الاشعار 778899 رصيدك 120000';

      final parsed = SmsSenderRegistry.parseMessage(
        sender: sender,
        body: body,
        date: testDate,
      );

      expect(parsed, isNotNull);
      expect(parsed!.walletType, 'busairi');
      expect(parsed.type, 'income');
      expect(parsed.amount, 50000.0);
      expect(parsed.balance, 120000.0);
      expect(parsed.referenceNumber, '778899');
    });

    test('WeePay (وي باي) deposit SMS parsed as weepay wallet (Income 10,000)', () {
      const sender = 'WeePay';
      const body = 'تم إيداع مبلغ 10000 ريال في محفظتك وي باي رصيدك 45000';

      final parsed = SmsSenderRegistry.parseMessage(
        sender: sender,
        body: body,
        date: testDate,
      );

      expect(parsed, isNotNull);
      expect(parsed!.walletType, 'weepay');
      expect(parsed.type, 'income');
      expect(parsed.amount, 10000.0);
      expect(parsed.balance, 45000.0);
    });

    test('Credit notice (إشعار دائن) parsed as income (Income 75,000)', () {
      const sender = 'KuraimiMB';
      const body = 'إشعار دائن بمبلغ 75,000 ريال لحسابكم رقم 123456 رصيدك 95,000 ريال';

      final parsed = SmsSenderRegistry.parseMessage(
        sender: sender,
        body: body,
        date: testDate,
      );

      expect(parsed, isNotNull);
      expect(parsed!.walletType, 'kuraimi');
      expect(parsed.type, 'income');
      expect(parsed.amount, 75000.0);
      expect(parsed.balance, 95000.0);
    });

    test('Reversal credit (عكس قيد لصالحك) parsed as income (Income 4,200)', () {
      const sender = 'Jaib';
      const body = 'عكس قيد لصالحك بمبلغ 4200 ر.ي في محفظتك جيب رصيدك 18200 ر.ي';

      final parsed = SmsSenderRegistry.parseMessage(
        sender: sender,
        body: body,
        date: testDate,
      );

      expect(parsed, isNotNull);
      expect(parsed!.walletType, 'jeeb');
      expect(parsed.type, 'income');
      expect(parsed.amount, 4200.0);
      expect(parsed.balance, 18200.0);
    });

    test('SmartSmsParser: deposit with phone and account number extracts amount not phone', () {
      const body = 'أودع/علي 771234567 لحسابك 12345678 بمبلغ 30,000 ريال رصيدك 80,000 ريال';
      final result = SmartSmsParser.analyzeSms(body: body, sender: 'UnknownBank');

      expect(result.isSuccess, isTrue);
      expect(result.type, 'income');
      expect(result.amount, 30000.0);
      expect(result.balance, 80000.0);
    });

    test('SmartSmsParser: inward transfer with sender phone extracts amount not phone', () {
      const body = 'تم تحويل 8000 ر.ي إلى محفظتك جيب من 777123456 رص: 23000ر.ي';
      final result = SmartSmsParser.analyzeSms(body: body, sender: 'UnknownBank');

      expect(result.isSuccess, isTrue);
      expect(result.type, 'income');
      expect(result.amount, 8000.0);
      expect(result.balance, 23000.0);
    });

    test('SmartSmsParser: credit advice in custom bank recognized as income', () {
      const body = 'اشعار دائن بمبلغ 1500 USD رصيدك الحالي 5200 USD';
      final result = SmartSmsParser.analyzeSms(body: body, sender: 'GlobalBank');

      expect(result.isSuccess, isTrue);
      expect(result.type, 'income');
      expect(result.amount, 1500.0);
      expect(result.balance, 5200.0);
    });
  });
}
